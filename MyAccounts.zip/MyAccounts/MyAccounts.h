//  Copyright © 2016 Neil Vitale. All rights reserved.


#import <UIKit/UIKit.h>

//! Project version number for MyAccounts.
FOUNDATION_EXPORT double MyAccountsVersionNumber;

//! Project version string for MyAccounts.
FOUNDATION_EXPORT const unsigned char MyAccountsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MyAccounts/PublicHeader.h>


